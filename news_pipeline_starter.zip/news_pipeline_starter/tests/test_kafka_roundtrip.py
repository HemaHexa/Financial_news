import json
import time
from uuid import uuid4
from kafka import KafkaProducer, KafkaConsumer
from config.settings import KAFKA_BOOTSTRAP_SERVERS, NEWS_TOPIC, PROJECT_ROOT

def main():
    token = uuid4().hex
    sample = {
        "schema_version": "1.0",
        "article_id": "test-" + token,
        "published_at": "2026-11-09T06:00:00+00:00",
        "source": "roundtrip-test",
        "headline": "Kafka producer-consumer connectivity test",
        "rss_description": "Sample event for local Kafka verification.",
        "full_text": "",
        "url": "https://example.com/test/" + token,
        "raw_html": "",
        "feed_url": "test",
        "ingested_at": "2026-11-09T06:01:00+00:00",
    }
    consumer = KafkaConsumer(
        NEWS_TOPIC, bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS.split(","),
        group_id="news-roundtrip-" + token, auto_offset_reset="earliest",
        enable_auto_commit=False, consumer_timeout_ms=20000,
        value_deserializer=lambda b: json.loads(b.decode("utf-8")),
    )
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS.split(","), acks="all",
        key_serializer=lambda k: k.encode("utf-8"),
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )
    try:
        time.sleep(2)
        producer.send(NEWS_TOPIC, key=sample["article_id"], value=sample).get(timeout=15)
        producer.flush()
        print("Published sample; waiting for consumer...")
        for message in consumer:
            if message.value.get("article_id") == sample["article_id"]:
                output = PROJECT_ROOT / "shared_data" / "test_output" / "roundtrip.jsonl"
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(message.value, ensure_ascii=False) + "\n")
                print("SUCCESS: received and saved sample to", output)
                return
        raise TimeoutError("Sample was not received within 20 seconds.")
    finally:
        consumer.close()
        producer.close()

if __name__ == "__main__":
    main()
