$ErrorActionPreference = "Stop"
$KafkaBin = "C:\kafka_2.13-4.4.0\bin\windows"
Push-Location $KafkaBin
try {
    .\kafka-topics.bat --bootstrap-server localhost:9092 --create --if-not-exists --topic raw-news-events --partitions 3 --replication-factor 1
    .\kafka-topics.bat --bootstrap-server localhost:9092 --create --if-not-exists --topic news-dead-letter --partitions 3 --replication-factor 1
    .\kafka-topics.bat --bootstrap-server localhost:9092 --list
}
finally { Pop-Location }
