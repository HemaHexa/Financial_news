import os
from pathlib import Path
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / "config" / ".env")

def path_setting(key, default):
    value = Path(os.getenv(key, default))
    return value if value.is_absolute() else PROJECT_ROOT / value

KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
NEWS_TOPIC = os.getenv("NEWS_TOPIC", "raw-news-events")
NEWS_DLQ_TOPIC = os.getenv("NEWS_DLQ_TOPIC", "news-dead-letter")
NEWS_POLL_SECONDS = int(os.getenv("NEWS_POLL_SECONDS", "60"))
NEWS_BUFFER_FILE = path_setting("NEWS_BUFFER_FILE", "shared_data/producer_buffer/news_pending.jsonl")
NEWS_OUTPUT_PATH = path_setting("NEWS_OUTPUT_PATH", "shared_data/bronze/news")
NEWS_CHECKPOINT_PATH = path_setting("NEWS_CHECKPOINT_PATH", "shared_data/checkpoints/news_bronze")
RSS_FEEDS = [v.strip() for v in os.getenv(
    "RSS_FEEDS",
    "https://news.google.com/rss/search?q=Indian+stock+market+NSE+BSE&hl=en-IN&gl=IN&ceid=IN:en"
).split(",") if v.strip()]
ARTICLE_FETCH_TIMEOUT = int(os.getenv("ARTICLE_FETCH_TIMEOUT", "15"))
MAX_ARTICLE_HTML_CHARS = int(os.getenv("MAX_ARTICLE_HTML_CHARS", "500000"))
