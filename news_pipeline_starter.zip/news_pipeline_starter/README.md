# News streaming starter (news scope only)

This package implements: RSS news -> Python Kafka producer -> `raw-news-events` -> PySpark Structured Streaming -> Parquet Bronze.

It does not create ticker/stock-price topics or ticker Bronze data; that work belongs to the other team member.

## Prerequisites
- Python 3.12 venv, Java 17, local Kafka broker at `localhost:9092`.
- Kafka 4.x in KRaft mode.
- Activate the project venv and install dependencies:

```powershell
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## 1. Create news topics
Run `scripts\create_news_topics.ps1`, or manually:

```powershell
cd C:\kafka_2.13-4.4.0\bin\windows
.\kafka-topics.bat --bootstrap-server localhost:9092 --create --if-not-exists --topic raw-news-events --partitions 3 --replication-factor 1
.\kafka-topics.bat --bootstrap-server localhost:9092 --create --if-not-exists --topic news-dead-letter --partitions 3 --replication-factor 1
.\kafka-topics.bat --bootstrap-server localhost:9092 --list
```

Start the broker separately and keep its terminal open:

```powershell
.\kafka-server-start.bat C:\kafka_2.13-4.4.0\config\server.properties
```

## 2. Verify producer-consumer communication first
From project root, with venv active:

```powershell
python tests\test_kafka_roundtrip.py
```

A successful test prints `SUCCESS` and saves the received sample JSON to `shared_data/test_output/roundtrip.jsonl`.

## 3. Start RSS ingestion
Copy `config\.env.example` to `config\.env`, then run:

```powershell
python -m src.producers.news_producer
```

Default RSS search feed is for Indian stock-market news. Polling interval defaults to 60 seconds. The producer deduplicates by URL hash and buffers events to disk if Kafka is unavailable, replaying buffered events in order after reconnecting.

Article text extraction is best effort. Some publishers block automated access or use paywalls/JavaScript. The RSS headline and description are retained; fetched HTML and extracted text are included when available.

## 4. Start PySpark Bronze writer
Check Spark version:

```powershell
python -c "import pyspark; print(pyspark.__version__)"
```

For PySpark 4.0.1, run:

```powershell
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.13:4.0.1 src\bronze\news_bronze.py
```

It writes append-only Parquet to `shared_data/bronze/news` and checkpoints to `shared_data/checkpoints/news_bronze`. Keep it running while the producer publishes.

## Bronze-to-Silver contract
- Format: plain Parquet (not Delta).
- Path: `shared_data/bronze/news`.
- `value` column: original Kafka JSON string, unchanged.
- Kafka metadata: topic, partition, offset, timestamp, key.
- Silver should parse `value` and perform cleaning/normalization/deduplication.

## Event fields
`schema_version`, `article_id`, `published_at`, `source`, `headline`, `rss_description`, `full_text`, `url`, `raw_html`, `feed_url`, `ingested_at`.
