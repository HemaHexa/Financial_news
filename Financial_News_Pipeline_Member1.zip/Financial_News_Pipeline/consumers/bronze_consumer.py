"""PySpark Structured Streaming: Kafka raw events -> six-column Bronze Parquet."""
import os
from pathlib import Path
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "raw-news-events")
BRONZE = str(ROOT / "data" / "bronze" / "news_history")
CHECKPOINT = str(ROOT / "data" / "bronze" / "checkpoint")
KAFKA_PACKAGE = os.getenv(
    "SPARK_KAFKA_PACKAGE",
    "org.apache.spark:spark-sql-kafka-0-10_2.13:4.3.0"
)


def main():
    spark = (SparkSession.builder.appName("FinancialNewsBronze")
             .master(os.getenv("SPARK_MASTER", "local[*]"))
             .config("spark.jars.packages", KAFKA_PACKAGE)
             .getOrCreate())
    spark.sparkContext.setLogLevel("WARN")

    stream = (spark.readStream.format("kafka")
              .option("kafka.bootstrap.servers", BOOTSTRAP)
              .option("subscribe", TOPIC)
              .option("startingOffsets", "earliest")
              .option("failOnDataLoss", "false")
              .load())

    bronze = stream.select(
        col("key").cast("string").alias("kafka_key"),
        col("value").cast("string").alias("raw_json"),
        col("topic").alias("topic"),
        col("partition").cast("int").alias("partition"),
        col("offset").cast("long").alias("offset"),
        col("timestamp").alias("kafka_ts"),
    )

    query = (bronze.writeStream.format("parquet")
             .outputMode("append")
             .option("path", BRONZE)
             .option("checkpointLocation", CHECKPOINT)
             .trigger(processingTime="1 minute")
             .start())
    print(f"Writing Bronze Parquet to: {BRONZE}")
    query.awaitTermination()


if __name__ == "__main__":
    main()
