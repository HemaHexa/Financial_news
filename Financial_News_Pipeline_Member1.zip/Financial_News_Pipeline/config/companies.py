TARGET_COMPANIES = [
    "Reliance Industries",
    "Tata Consultancy Services",
    "Infosys",
    "HDFC Bank",
    "ICICI Bank",
    "Tata Steel",
    "State Bank of India",
    "ITC",
    "Sun Pharmaceutical",
    "Bharti Airtel",
    "Adani Enterprises",
    "Coal India",
    "Bajaj Finance",
    "Hindalco Industries",
    "Oil and Natural Gas Corporation",
]
NEWS_SOURCES = ["Business Standard", "Moneycontrol", "CNBC-TV18", "Mint"]
REFRESH_INTERVAL_MINUTES = 15
