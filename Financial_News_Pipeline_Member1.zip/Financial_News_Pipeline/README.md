# Financial News Pipeline — Member 1

## Scope
- 15 target companies are listed in `config/companies.py`.
- Public RSS feeds: Business Standard, Moneycontrol, CNBC-TV18, Mint.
- RSS-only: no article-page web scraping.
- Initial baseline on startup, then refresh every 15 minutes.
- Kafka topic: `raw-news-events`.
- Bronze output: Parquet with six agreed columns.
- Company matching and deduplication belong to Silver, not Producer/Bronze.

## RSS history limitation
The first run is a baseline of entries currently exposed by the four RSS feeds, not a complete historical archive. Publishers control feed contents and retention. RSS may expose only headlines, summaries, links and limited history. The producer publishes all feed entries without company filtering; Silver must match them to the 15 companies. Repeated entries across cycles are expected and Silver should deduplicate.

## Setup
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Kafka
Start your existing Kafka server using your separate project config. Create the topic only if it does not already exist:
```powershell
cd C:\kafka
.\bin\windows\kafka-topics.bat --create --topic raw-news-events --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1
```

## Run producer
From project root:
```powershell
.\.venv\Scripts\Activate.ps1
python producers\news_producer.py
```
Stop with Ctrl+C. Failed Kafka sends are appended to `data/spool/failed_news.jsonl` and replay is attempted on the next polling cycle. This is a basic local recovery buffer, not a fully hardened production queue.

## Verify Kafka
```powershell
cd C:\kafka
.\bin\windows\kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic raw-news-events --from-beginning
```

## Run Bronze
Requires your separate Spark installation and a Kafka connector package matching the exact Spark/Scala versions:
```powershell
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.13:4.3.0 consumers\bronze_consumer.py
```
If Maven access is blocked, arrange the matching connector JAR through an approved local/internal source.

Bronze columns: `kafka_key` (string), `raw_json` (string), `topic` (string), `partition` (int), `offset` (long), `kafka_ts` (timestamp).

Output: `data/bronze/news_history`
Checkpoint: `data/bronze/checkpoint`

Do not delete the active checkpoint during normal operation. A separate controlled backfill should be used for a baseline refresh after a few months, preserving existing Bronze history.

## Limitations
- Feed URLs and access can change.
- RSS does not guarantee complete historical coverage or full article text.
- No scraping, company matching, or deduplication is performed here.
- Connector coordinates may need to be adjusted to your installed Spark/Scala build.
