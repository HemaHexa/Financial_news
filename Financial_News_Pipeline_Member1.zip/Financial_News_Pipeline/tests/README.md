Validation checklist:
1. Check each publisher's RSS fetch count.
2. Confirm Kafka records arrive in raw-news-events.
3. Stop Kafka temporarily and check that failed records enter data/spool/failed_news.jsonl.
4. Restart Kafka and check spool replay.
5. Run Bronze and verify the six expected Parquet columns.
